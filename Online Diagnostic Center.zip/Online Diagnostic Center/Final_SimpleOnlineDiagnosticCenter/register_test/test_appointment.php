<?php

include "../includes/dbFunctions.php";

session_start();

$appointmentDay = $_POST['appointment_date'];
$appointmentTime = $_POST['appointment_time'];
$test_id = $_POST['test_id'];
$patient_id = $_POST['patient_id'];

if(insertTestAppointment($appointmentDay, $appointmentTime, $test_id, $patient_id)){
    $_SESSION["message"] = "Test Appointment Successfully Add";
    header("Location: /register_test/dashboard.php");
}else{
    $_SESSION["message"] = "Something went wrong!";
    header("Location: /register_test/register_test.php");
}
