<?php


include "patient_drawer.php";
session_start();
$title="Doctor Portal";
$doctor = findDoctorByUserId($_SESSION['user_id']);
$appointments = getDoctorAppointments($doctor['idDoctor']);
$fetchedTests = getAllTests();
?>


<div class="mdui-valign">
    <div class="mdui-typo-headline-opacity mdui-center">Pathology Test</div>
</div>


<div class="mdui-m-a-1 mdui-row">
    <?php
        foreach ($fetchedTests as $testaddingadmin){
            echo "<div class=\"mdui-col-xs-6 mdui-col-sm-4\" >
                        <div class=\"mdui-card mdui-m-a-1\">
                            <div class=\"mdui-card-media\" >
                              
                                <img src=\"../images/test.png\"/ >
                            </div>
                            <div class=\"mdui-card-primary\" style=\"min-height: 60px !important; max-height: 90px !important;\">
                              <div class=\"mdui-text-capitalize\" >".$testaddingadmin['TestName']."</div>
                            </div>
							<div class=\"mdui-card-actions\">
                                <button class=\"mdui-btn mdui-ripple\" onclick='location.href=\"appointment_form_test.php?testId=".$testaddingadmin['idTest']."\"'>Make Appointment</button>
                            </div>
                        </div>
                  </div>";
        }
    ?>
</div>












<script type="text/javascript">

    document.title = "<?=$title;?>";
    $('#dashboard_title').text("<?=$title;?>");
    $('#dashboard_file').text("Doctors Information");

    $.validate({
        form: '#login_form, #register_form',
        modules: 'security',
        onModulesLoaded : function() {
        }
    });

</script>

<?php include("../includes/portal_components/footer.php");?>
