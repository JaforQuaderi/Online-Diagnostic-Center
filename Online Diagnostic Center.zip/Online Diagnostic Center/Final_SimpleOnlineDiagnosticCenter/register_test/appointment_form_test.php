<?php
include "patient_drawer.php";
session_start();
date_default_timezone_set('Asia/Dhaka');
$title="Patient Portal";
$testId = $_GET['testId'];
$patientID = findPatientIdByUserId($_SESSION['user_id']);
?>







<div class="mdui-card" id="login_card" style="width: 500px; margin: 0 auto; margin-top: 100px;">
    <div class="mdui-card-header mdui-color-indigo" style="height: 100px;">
        <div class="mdui-card-primary-title">Appointment</div>
    </div>

    <div class="mdui-card-content">
        <form method="post" action="test_appointment.php" id="register_form">
            <input name="test_id" hidden value="<?php echo $testId; ?>"/>
            <input name="patient_id" hidden value="<?php echo $patientID; ?>"/>
            <div class="mdui-textfield">
                <label class="mdui-textfield-label" for="date_selection">Appointment Date</label>
                <input class="mdui-textfield-input" type="date" name="appointment_date" id="date_selection">
            </div>
            <div class="mdui-textfield">
                <label class="mdui-textfield-label" for="time_selection">Time Slot</label>
                <select class="mdui-textfield-input" name="appointment_time" id="time_selection">
                    <option value="08:00">08:00 AM</option>
                    <option value="08:00">09:00 AM</option>
                    <option value="08:00">10:00 AM</option>
                    <option value="08:00">11:00 AM</option>
                    <option value="08:00">12:00 PM</option>
                    <option value="08:00">03:00 PM</option>
                    <option value="08:00">04:00 PM</option>
                    <option value="08:00">05:00 PM</option>
                    <option value="08:00">06:00 PM</option>
                    <option value="08:00">07:00 PM</option>
                    <option value="08:00">08:00 PM</option>
                    <option value="08:00">09:00 PM</option>
                </select>
            </div>
            <button class="mdui-btn mdui-ripple mdui-color-green mdui-float-right login-register-button" style="margin: 10px;" type="submit" id="register_submit" name="submit">Register</button>
        </form>
    </div>
</div>





<script type="text/javascript">
    document.title = "<?=$title;?>";
    $('#dashboard_title').text("<?=$title;?>");
    $('#dashboard_file').text("New Appointment");
</script>
<?php include("../includes/portal_components/footer.php");?>
