<?php
include "includes/components/header.php";
?>
<div class="mdui-container-fluid" style="margin-top: 100px">
    <h1 style="text-align:center">Additional Services</h1>

    <div class="mdui-row">
        <div class="mdui-col-sm-3">
            <button data-scroll-tp=""
                    class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-blue header-part-btn mdui-text-capitalize"
                    id="ambulance_services">Ambulance Services
            </button>
            <br><br>
            <button data-scroll-tp=""
                    class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-yellow header-part-btn mdui-text-capitalize"
                    id="pharmacy">Pharmacy Near Us
            </button>
            <br><br>
            <button data-scroll-tp=""
                    class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-blue header-part-btn mdui-text-capitalize"
                    id="hospital">Hospital Near Us
            </button>
            <br><br>
            <button data-scroll-tp=""
                    class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-yellow header-part-btn mdui-text-capitalize"
                    id="room_information">Room Information
            </button>
            <br><br><br><br><br><br>

        </div>
        <div class="mdui-col-sm-9">
            <iframe id="map_frame"
                    width="920"
                    height="800"
                    frameborder="0" style="border:0;"
                    src="https://www.google.com/maps/embed/v1/search?key=AIzaSyDFrXZv9nB7SNw1m7a5FwSJlj-mymFESWg&zoom=12&q=ambulance+services+near+me"
                    allowfullscreen>
            </iframe>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#ambulance_services').click(function () {
        $('#map_frame').attr("src", "https://www.google.com/maps/embed/v1/search?key=AIzaSyDFrXZv9nB7SNw1m7a5FwSJlj-mymFESWg&zoom=12&q=ambulance+services+near+me");
    });

    $('#pharmacy').click(function () {
        $('#map_frame').attr("src", "https://www.google.com/maps/embed/v1/search?key=AIzaSyDFrXZv9nB7SNw1m7a5FwSJlj-mymFESWg&zoom=12&q=pharmacy+near+me");
    });

    $('#hospital').click(function () {
        $('#map_frame').attr("src", "https://www.google.com/maps/embed/v1/search?key=AIzaSyDFrXZv9nB7SNw1m7a5FwSJlj-mymFESWg&zoom=12&q=hospital+near+me");
    });

    $('#room_information').click(function () {
        location.href = "room_information.php";
    });
</script>


<?php
include "includes/components/footer.php";
?>
