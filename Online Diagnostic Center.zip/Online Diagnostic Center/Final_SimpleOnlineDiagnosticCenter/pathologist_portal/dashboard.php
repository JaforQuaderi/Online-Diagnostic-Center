<?php
include("./pathologist_drawer.php");

$title="Pathologist Portal";
$idUser = $_SESSION['user_id'];
$pathologist = findPathologistById($idUser);
$testAppointment = getTestAppointmentTable($pathologist["Department"]);
?>

<h1>Test Reports</h1>
<table class="mdui-table mdui-table-hoverable">
    <thead>
    <tr>
        <th>Date</th>
        <th>Status</th>
        <th>Result</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>

    <?php
    foreach ($testAppointment as $test){
        echo "<tr>
                    <td>".$test['TestDate']."</td>
                    <td>".$test['status']."</td>
                    <td>".$test['result']."</td>
                    <td class=\"mdui-text-center\"><a href='make_report.php?tappId=".$test["idAppointmentTestTimeTable"]."' class=\"mdui-btn mdui-color-teal mdui-ripple\">Report</a></td>
                </tr>";
    }
    ?>
    </tbody>
</table>


<script type="text/javascript">
    document.title = "<?=$title;?>";
    $('#dashboard_title').text("<?=$title;?>");
    $('#dashboard_file').text("Dashboard");
</script>
<?php include("../includes/portal_components/footer.php");?>
