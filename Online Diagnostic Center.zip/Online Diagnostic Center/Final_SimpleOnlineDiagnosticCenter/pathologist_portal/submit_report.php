<?php

include "../includes/dbFunctions.php";
session_start();

$testResult = $_POST['test_result'];
$testAppointId = $_POST['tappid'];

if(updateTestResult($testResult, $testAppointId)){
    $_SESSION['message'] = "Update successfully applied";
    header("Location: /pathologist_portal/dashboard.php");
}else{
    $_SESSION['message'] = "Update Unsuccessful";
    header("Location: /pathologist_portal/dashboard.php");
}


