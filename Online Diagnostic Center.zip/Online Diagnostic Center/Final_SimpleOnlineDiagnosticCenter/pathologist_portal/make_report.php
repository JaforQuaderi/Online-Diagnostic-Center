<?php
include "pathologist_drawer.php";
session_start();
date_default_timezone_set('Asia/Dhaka');
$title="Patient Portal";
$appointmentId = $_GET['tappId'];
?>

<div class="mdui-card" id="login_card" style="width: 500px; margin: 0 auto; margin-top: 100px;">
    <div class="mdui-card-header mdui-color-indigo" style="height: 100px;">
        <div class="mdui-card-primary-title">Report</div>
    </div>

    <div class="mdui-card-content">
        <form method="post" action="submit_report.php" id="register_form">
            <input name="tappid" hidden value="<?php echo $appointmentId; ?>"/>
            <div class="mdui-textfield">
                <label class="mdui-textfield-label" for="result_des">Report Description</label>
                <textarea rows="3" class="mdui-textfield-input" name="test_result" id="result_des"></textarea>
            </div>
            <button class="mdui-btn mdui-ripple mdui-color-green mdui-float-right login-register-button" style="margin: 10px;" type="submit" id="register_submit" name="submit">
                Submit
            </button>
        </form>
    </div>
</div>

<script type="text/javascript">
    document.title = "<?=$title;?>";
    $('#dashboard_title').text("<?=$title;?>");
    $('#dashboard_file').text("Make Report");
</script>
<?php include("../includes/portal_components/footer.php");?>
