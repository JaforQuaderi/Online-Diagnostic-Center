<?php
include "includes/components/header.php";
?>
<div class="mdui-container-fluid" style="margin-top: 100px">

    <div class="mdui-row">
        <h1 class="mdui-text-center">Branches Contact Information</h1>
        <table class="mdui-table mdui-table-hoverable">
            <thead>
            <tr>
                <th class="column1">District</th>
				<th class="column2">Address</th>
				<th class="column3" style = "text-align:center">Phone</th>
				<th class="column4" style = "text-align:center">Email</th>
            </tr>
            </thead>
            <tbody>
								<tr>
									<td class="column1">Barishal</td>
									<td class="column2">K Jahan Center, House # 106, Sadar Road</td>
									<td class="column3" style = "text-align:center">01766663005</td>
									<td class="column4">jalailshikder@abcgroup.com</td>
								</tr>
								<tr>
									<td class="column1">Chittagong</td>
									<td class="column2">Forum Central, 787/863, M. M. Ali Road Gole Pahar More, Mehedigab</td>
									<td class="column3" style = "text-align:center">01766660137</td>
									<td class="column4">info@abcgroup.com</td>
								</tr>
								<tr>
									<td class="column1">Faridpur</td>
									<td class="column2">5/1 Niltuli, Mujib Sarak</td>
									<td class="column3" style = "text-align:center">01766662651</td>
									<td class="column4">aminul@abcgroup.com</td>
								</tr>
								<tr>
									<td class="column1">Jessore</td>
									<td class="column2">Holding # 498/2, Jail Road, Ghope</td>
									<td class="column3" style = "text-align:center">01766663318</td>
									<td class="column4">islam@abcgroup.com</td>
								</tr>
								<tr>
									<td class="column1">Khulna</td>
									<td class="column2">Plot # A-5, Mojid Sarani,Sonadanga</td>
									<td class="column3" style = "text-align:center">01766660254</td>
									<td class="column4">amzad_khulna@abcgroup.com</td>
								</tr>
								<tr>
									<td class="column1">Mymensingh</td>
									<td class="column2">72 Charpara, Medical College Gate</td>
									<td class="column3" style = "text-align:center">01766663317</td>
									<td class="column4">lutfar@abcgroup.com</td>
								</tr>
								<tr>
									<td class="column1">Rangpur</td>
									<td class="column2">House # 69, Road # 1, Dhap Jail Road</td>
									<td class="column3" style = "text-align:center">01766660358</td>
									<td class="column4">faridalam@abcgroup.com</td>
								</tr>
								<tr>
									<td class="column1">Sylhet</td>
									<td class="column2">189, East Dargah Gate</td>
									<td class="column3" style = "text-align:center">01766660135</td>
									<td class="column4">sylhet@abcgroup.com</td>
								</tr>
            </tbody>
        </table>
		<br><br><br>
    </div>
</div>


<?php
include "includes/components/footer.php";
?>
