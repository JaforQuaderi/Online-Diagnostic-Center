<?php
include "includes/components/header.php";
?>
<div class="mdui-container-fluid" style="margin-top: 100px">

    <div class="mdui-row">
        <div class="mdui-col-sm-3">
            <button data-scroll-tp=""
                    class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-blue header-part-btn mdui-text-capitalize"
                    id="ambulance_services">Mission Vision Values
            </button>
            <br><br>
            <button data-scroll-tp=""
                    class="mdui-btn mdui-btn-raised mdui-ripple mdui-color-yellow header-part-btn mdui-text-capitalize"
                    id="pharmacy">Quality Control
            </button>
            <br><br><br><br><br><br>

        </div>
        <div class="mdui-col-sm-9">
            <iframe id="map_frame"
                    width="920"
                    height="800"
                    frameborder="0" style="border:0;"
                    src="about_us/mission_vision_values.php"
                    allowfullscreen>
            </iframe>
        </div>
    </div>
</div>
<script type="text/javascript">
    $('#ambulance_services').click(function () {
        $('#map_frame').attr("src", "about_us/mission_vision_values.php");
    });

    $('#pharmacy').click(function () {
        $('#map_frame').attr("src", "about_us/quality_control.php");
    });
</script>


<?php
include "includes/components/footer.php";
?>
