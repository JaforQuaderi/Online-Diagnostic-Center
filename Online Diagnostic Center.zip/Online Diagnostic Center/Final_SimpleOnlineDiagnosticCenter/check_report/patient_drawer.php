<?php
include "../includes/auth_functions.php";
include "../includes/dbFunctions.php";
session_start();

if(isLoggedIn()) {
    if($_SESSION['user_type'] != "Patient"){
        header("Location: /patient_portal/patient_login.php");
        exit();
    }
} else {
    header("Location: /patient_portal/patient_login.php");
    exit();
}

include "../includes/portal_components/header_appointment.php";
$tempUser['username'] = $_SESSION['username'];
$tempUser['user_type'] = 'Patient';
$user = findUserByUsername($tempUser);
?>

<?php
if($_SESSION["message"] != ""){
    echo "<script>mdui.snackbar({message: '".$_SESSION["message"]."', timeout: 5000});</script>";
    $_SESSION["message"] = "";
}
?>

<div class="mdui-drawer mdui-shadow-5" id="drawer">
    <ul class="mdui-list">
        <li class="mdui-list-item">

            <div class="mdui-list-item-content" style="min-height: 150px;">
                <div>
                    <?php echo'<img class="mdui-img-circle" style="width: 100px;" src="data:image/jpeg;base64,'.$user['Image'].'" alt="Image not found" onerror="this.onerror=null;this.src=\'../images/users.png\';" />'?>
                    <br>
                    <h3 class="mdui-float-left"><?php echo $_SESSION['username'] ?></h3>
                </div>
            </div>
        </li>
    </ul>
</div>

<div class="mdui-container">