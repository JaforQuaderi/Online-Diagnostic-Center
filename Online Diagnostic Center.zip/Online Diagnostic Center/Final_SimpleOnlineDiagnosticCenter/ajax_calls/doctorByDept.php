<?php

include "../includes/dbFunctions.php";
$department = $_POST['department'];

$fetchedDoctor = getAllDoctorsByDepartment($department);
echo json_encode($fetchedDoctor);


?>