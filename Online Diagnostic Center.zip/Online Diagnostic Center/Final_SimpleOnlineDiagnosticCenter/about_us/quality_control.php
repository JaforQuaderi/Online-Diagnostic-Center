<!DOCTYPE html>
<html lang="en" >

<head>

<style>
body {
    background-color: #607D8B;
}

h1{
    color: white;
} 

h2{
    color: white;
}

p{
    color: white;
	margin-left: 40px;
} 
</style>



</head>

<body>
	
	
  <h1 style = "text-align: center">Qualtity Control</h1><br><br>
  
  <h2><u> Quality Assurance </u></h2>
  <p>The quality of lab tests at ABC Diagnostics is ensured at every step from sample collection to testing to reporting.</p><br><br>
  
  <h2><u> Sample Collection </u></h2>
  <p>The samples for laboratory tests are collected by our experienced technicians who are rained adequately prior to placement for 
  collection of samples following standardized procedures. It is a must for them to wear lab coats while working in sample collection booths. 
  They must use sterile and disposable gloves during collection of samples. Labaid Diagnostics uses high quality disposable Vacuettes imported 
  from USA and disposable syringes for blood sample collection, storage and transport to the labs.</p><br><br>

  <h2><u> Waste disposal </u></h2>
  <p>We strictly follow internationally acceptable and nationally instructed guidelines for laboratory waste disposal. 
  There are different covered colored bins for specific types of pathological wastes. Labaid has an agreement with PRISM –
  an organization with government approval for medical waste management, to collect the accumulated medical wastes from ABC Diagnostics, 
  ABC Specialized Hospital and ABC Cardiac Hospital and they take away to their waste management site outside Dhaka City 
  and destroy them after treating according to the nature of waste products.</p><br><br>
  
  <h2><u> Internal Quality Control </u></h2>
  <p>Every lab has its own internal quality control system to validate tests being done. 
  The respective consultants ensure that the test-results are without aberrations, and do repeat test if deemed necessary. 
  There is provision for incorporating addresses and contact telephone numbers of the patients so that if a consultant 
  of any laboratory finds any sample to be not suitable or test result unusual, s/he manages to contact with the patient, 
  rearranges sampling and takes history of the illness for the purpose of validating test result or re-testing the sample.</p><br><br>
  
  <h2><u> External Quality Control </u></h2>
  <p>Labaid Ltd partners with world famous lab quality control organization – BIORAD of USA through its Indian subsidiary for
  external quality control program for biochemistry tests. BIORAD, India supplies quality control samples of unknown readings. 
  The samples are run using the reagents we use for various biochemical tests and results sent to BIORAD for comparing with the actual
  readings. So far Labaid Diagnostics has been consistent with the BIORAD readings and successfully conformed to the international 
  standards that BIORAD advocates to maintain all over the world.</p><br><br>


</body>

</html>
