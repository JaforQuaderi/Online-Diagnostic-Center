<!DOCTYPE html>
<html lang="en" >

<head>

<style>
body {
    background-color: #607D8B;
}

h1{
    color: white;
}

h3{
    color: white;
	margin-left: 40px;
} 
</style>



</head>

<body>
	
	
  <h1 style = "text-align: center">Our Mission, Vision & Values</h1><br><br>
  
  <h3>Meeting the requirements of our patients consistently Providing accuracy in Clinical & 
  Diagnostic checks Providing reliability in our Test Results & Quality in the services Managing 
  Medical Services backed by high levels of patient care & sensitivity Attaining Leadership 
  through Medical Expertise & Professional Management Confidentiality & Integrity for the patients 
  Strive towards Excellence & Perfection Offering Ethical & Transparent business practice</h3><br><br>
  
	


</body>

</html>
