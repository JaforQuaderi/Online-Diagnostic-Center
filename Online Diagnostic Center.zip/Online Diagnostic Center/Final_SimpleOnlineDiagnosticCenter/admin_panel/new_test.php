<?php


include "../includes/dbFunctions.php";
session_start();
$testaddingadmin['TestName'] = $_POST['TestName'];


    if(insertNewTest($testaddingadmin)){
        $_SESSION["message"] = "Test Registration Successful";
        header("Location: /admin_panel/pathology.php");
    }else{
        $_SESSION["message"] = "Test Registration Unsuccessful";
        header("Location: /admin_panel/pathology.php");
    }



?>


