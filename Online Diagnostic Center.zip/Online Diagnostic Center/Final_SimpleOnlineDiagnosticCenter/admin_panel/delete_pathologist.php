<?php


include "../includes/dbFunctions.php";
session_start();

$idPathologist = $_POST['del_pathologist_id'];
if(deletePathologist($idPathologist)){
    $_SESSION['message'] = "Pathologist Deleted successfully";
		header("Location: /admin_panel/pathologists.php");
    }
else{
    $_SESSION["message"] = "Pathologist Deletation Unsuccessful";
		header("Location: /admin_panel/pathologists.php");
    }


?>