<?php


include("admin_drawer.php");
$title="Admin Panel";

$fetchedTests = getAllTests();

?>


<div class="mdui-m-a-5 mdui-clearfix">
    <button class="mdui-btn mdui-ripple mdui-color-theme-accent mdui-text-capitalize mdui-float-left mdui-color-green" mdui-dialog="{target: '#testRegistrationDialog'}">Add a new Test</button>
    <button class="mdui-btn mdui-ripple mdui-color-theme-accent mdui-text-capitalize mdui-float-right mdui-color-red" mdui-dialog="{target: '#testDeleteDialog'}">Delete a Test</button>
</div>

<div class="mdui-valign">
    <div class="mdui-typo-headline-opacity mdui-center">Pathology Test</div>
</div>


<div class="mdui-m-a-1 mdui-row">
    <?php
        foreach ($fetchedTests as $testaddingadmin){
            echo "<div class=\"mdui-col-xs-6 mdui-col-sm-4\" >
                        <div class=\"mdui-card mdui-m-a-1\">
                            <div class=\"mdui-card-media\" >
                              
                                <img src=\"../images/test.png\"/ >
                            </div>
                            <div class=\"mdui-card-primary\" style=\"min-height: 60px !important; max-height: 90px !important;\">
                              <div class=\"mdui-text-capitalize\" >".$testaddingadmin['TestName']."</div>
                            </div>
                        </div>
                  </div>";
        }
    ?>
</div>




















<div class="mdui-dialog mdui-color-yellow-100" id="testDeleteDialog">
    <div class="mdui-dialog-title">Delete Test</div>
    <div class="mdui-dialog-content">
        <form method="post" action="delete_test.php" id="register_form">
            <div class="mdui-textfield mdui-textfield-floating-label">
                <label class="mdui-textfield-label">Select Test</label>
                <select class="mdui-textfield-input" name="test_test_id">
                    <?php
                    foreach ($fetchedTests as $testaddingadmin){
						echo '<option value="'.$testaddingadmin["idTest"].'">'.$testaddingadmin["TestName"].'</option>';
                    }
                    ?>
                </select>
            </div>
            <button class="mdui-btn mdui-ripple mdui-color-red mdui-float-right login-register-button" type="submit" id="register_submit" name="submit">Delete Test</button>
        </form>
    </div>
</div>


<div class="mdui-dialog mdui-color-lime-100" id="testRegistrationDialog">
    <div class="mdui-dialog-title">Register Test</div>
    <div class="mdui-dialog-content">
        <form method="post" action="new_test.php" id="register_form">
            <div class="mdui-textfield">
                <input class="mdui-textfield-input mdui-text-capitalize" type="text" name="TestName" data-validation="custom" data-validation-regexp="^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$" data-validation-error-msg="Enter new pathology test name!" placeholder="Pathology Test Name" />
            </div>
            <button class="mdui-btn mdui-ripple mdui-color-green mdui-float-right login-register-button" type="submit" id="register_submit" name="submit">Register</button>
        </form>
    </div>
</div>





















<script type="text/javascript">

    document.title = "<?=$title;?>";
    $('#dashboard_title').text("<?=$title;?>");
    $('#dashboard_file').text("Pathology Tests Information");

    $.validate({
        form: '#login_form, #register_form',
        modules: 'security',
        onModulesLoaded : function() {
            var optionalConfig = {
                fontSize: '12pt',
                padding: '4px',
                bad: 'Very bad',
                weak: 'Weak',
                good: 'Good',
                strong: 'Strong'
            };
            $('input[name="rpassword"]').displayPasswordStrength(optionalConfig);
        }
    });

</script>

<?php include("../includes/portal_components/footer.php");?>
