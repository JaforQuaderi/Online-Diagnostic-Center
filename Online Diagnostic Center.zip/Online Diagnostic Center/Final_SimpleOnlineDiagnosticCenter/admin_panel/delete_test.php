<?php


include "../includes/dbFunctions.php";
session_start();

$idTest = $_POST['test_test_id'];
if(deleteTest($idTest)){
    $_SESSION['message'] = "Test Deleted successfully";
		header("Location: /admin_panel/pathology.php");
    }
else{
    $_SESSION["message"] = "Test Deletation Unsuccessful";
		header("Location: /admin_panel/pathology.php");
    }


?>