<?php


include "../includes/dbFunctions.php";
session_start();

$idDoctor = $_POST['del_doctor_id'];
if(deleteDoctor($idDoctor)){
    $_SESSION['message'] = "Doctor Deleted successfully";
		header("Location: /admin_panel/doctors.php");
    }
else{
    $_SESSION["message"] = "Doctor Deletation Unsuccessful";
		header("Location: /admin_panel/doctors.php");
    }


?>