<?php


include "../includes/dbFunctions.php";
session_start();

$idAppointmentTimeTable = $_POST['schedule_id'];
if(deleteDoctorSchedule($idAppointmentTimeTable)){
    $_SESSION['message'] = "Schedule Deleted successfully";
		header("Location: schedules.php");
    }
else{
    $_SESSION["message"] = "Schedule Deletation Unsuccessful";
		header("Location: schedules.php");
    }


?>