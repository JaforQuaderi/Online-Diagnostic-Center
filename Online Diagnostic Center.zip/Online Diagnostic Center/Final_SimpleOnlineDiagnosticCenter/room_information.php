<?php
include "includes/components/header.php";
?>
<div class="mdui-container-fluid" style="margin-top: 100px">

    <div class="mdui-row">
        <h1 class="mdui-text-center">Room Information</h1>
        <table class="mdui-table mdui-table-hoverable">
            <thead>
            <tr>
				<th class="column1">Section</th>
				<th class="column2">Room Number</th>
            </tr>
            </thead>
            <tbody>
		<tr>
			<td>Reception</td>
			<td>101</td>
		</tr>
		<tr>
			<td>Waiting Room</td>
			<td>102</td>
		</tr>
		<tr>
			<td>Help Desk</td>
			<td>103</td>
		</tr>
		<tr>
				<td>Doctor Cember's Room Numbers</td>
				<td>201, 301, 401, 501, 601, 701, 801</td>
			</tr>
		<tr>
				<td>Blood Test Room</td>
				<td>203</td>
			</tr>
		<tr>
				<td>ECG</td>
				<td>204</td>
			</tr>
		<tr>
				<td>X-Ray</td>
				<td>303</td>
			</tr>
		<tr>
				<td>MRI</td>
				<td>304</td>
			</tr>
		<tr>
				<td>City Scan</td>
				<td>307</td>
			</tr>
		<tr>
				<td>Ultrasonography</td>
				<td>402</td>
			</tr>
		<tr>
				<td>Prayer Room</td>
				<td>808</td>
			</tr>
		<tr>
				<td>Canteen</td>
				<td>809</td>
			</tr>
	</tbody>
        </table>
    </div>
</div>


<?php
include "includes/components/footer.php";
?>
