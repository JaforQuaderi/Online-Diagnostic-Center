-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 29, 2018 at 09:45 AM
-- Server version: 5.6.34-log
-- PHP Version: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `diagnosticcenter`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `idAdmin` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Department` varchar(45) NOT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`idAdmin`, `Name`, `Department`, `User_idUser`) VALUES
(2, 'Shah Jafor Sadeek Quaderi', 'HR', 13),
(3, 'Sakib Hasan', 'HR', 14);

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `idAppointment` int(11) NOT NULL,
  `AppointmentDate` date NOT NULL,
  `AppointmentTime` varchar(45) NOT NULL,
  `Patient_idPatient` int(11) NOT NULL,
  `Doctor_idDoctor` int(11) NOT NULL,
  `RegistrationDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`idAppointment`, `AppointmentDate`, `AppointmentTime`, `Patient_idPatient`, `Doctor_idDoctor`, `RegistrationDate`) VALUES
(5, '2017-08-06', '05:00-08:00', 1, 3, '2017-08-01'),
(7, '2017-08-13', '05:00-08:00', 3, 3, '2017-08-07'),
(8, '2018-03-26', '05:00-08:00', 6, 3, '2018-03-23'),
(9, '2018-03-26', '05:00-08:00', 8, 3, '2018-03-26'),
(10, '2018-03-31', '03:30-06:00', 9, 1, '2018-03-29');

-- --------------------------------------------------------

--
-- Table structure for table `appointmenttesttimetable`
--

CREATE TABLE `appointmenttesttimetable` (
  `idAppointmentTestTimeTable` int(11) NOT NULL,
  `TestDate` date NOT NULL,
  `TestTime` varchar(45) NOT NULL,
  `idTest` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `status` varchar(10) DEFAULT 'Testing',
  `result` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointmenttesttimetable`
--

INSERT INTO `appointmenttesttimetable` (`idAppointmentTestTimeTable`, `TestDate`, `TestTime`, `idTest`, `patient_id`, `status`, `result`) VALUES
(1, '2018-03-26', '08:00', 5, 3, 'Testing', NULL),
(2, '2018-03-05', '08:00', 1, 3, 'Done', 'Hello, You will die!'),
(3, '2018-03-27', '08:00', 5, 1, 'Done', 'You will be die.'),
(4, '2018-03-26', '08:00', 4, 8, 'Done', 'WoW!!!\r\nYou can live only 2 days...'),
(5, '2018-03-31', '08:00', 1, 9, 'Done', 'Neck broken...');

-- --------------------------------------------------------

--
-- Table structure for table `appointmenttimetable`
--

CREATE TABLE `appointmenttimetable` (
  `idAppointmentTimeTable` int(11) NOT NULL,
  `VisitingTime` varchar(45) NOT NULL,
  `VisitingDay` varchar(45) NOT NULL,
  `Doctor_idDoctor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointmenttimetable`
--

INSERT INTO `appointmenttimetable` (`idAppointmentTimeTable`, `VisitingTime`, `VisitingDay`, `Doctor_idDoctor`) VALUES
(1, '17:00-20:00', 'Sunday', 3),
(2, '17:00-20:00', 'Monday', 3),
(3, '16:00-18:00', 'Friday', 1),
(4, '16:00-18:00', 'Saturday', 1),
(5, '17:00-21:00', 'Wednesday', 1),
(6, '17:00-21:00', 'Thursday', 1),
(7, '10:00-14:00', 'Sunday', 2),
(8, '10:00-14:00', 'Monday', 2),
(9, '14:00-18:00', 'Tuesday', 2),
(11, '14:00-18:00', 'Wednesday', 2),
(12, '16:00-19:00', 'Tuesday', 3),
(13, '16:00-19:00', 'Wednesday', 3),
(14, '08:00-12:00', 'Friday', 4),
(15, '08:00-12:00', 'Saturday', 4),
(16, '17:00-20:00', 'Wednesday', 4),
(17, '17:00-20:00', 'Thursday', 4),
(18, '11:00-14:00', 'Monday', 5),
(19, '11:00-14:00', 'Tuesday', 5),
(20, '14:00-17:00', 'Wednesday', 5),
(21, '14:00-17:00', 'Thursday', 5),
(22, '14:00-17:00', 'Thursday', 6),
(23, '14:00-17:00', 'Friday', 6),
(24, '13:00-16:00', 'Saturday', 6),
(25, '13:00-16:00', 'Sunday', 6),
(26, '17:00-21:00', 'Wednesday', 7),
(27, '17:00-21:00', 'Thursday', 7),
(28, '10:00-14:00', 'Sunday', 7),
(29, '10:00-14:00', 'Monday', 7),
(30, '14:00-18:00', 'Tuesday', 8),
(31, '14:00-18:00', 'Wednesday', 8),
(32, '16:00-19:00', 'Tuesday', 8),
(33, '16:00-19:00', 'Wednesday', 8),
(34, '08:00-12:00', 'Friday', 9),
(35, '08:00-12:00', 'Saturday', 9),
(36, '17:00-20:00', 'Wednesday', 9),
(37, '17:00-20:00', 'Thursday', 9),
(38, '11:00-14:00', 'Monday', 10),
(39, '11:00-14:00', 'Tuesday', 10),
(40, '14:00-17:00', 'Wednesday', 10),
(41, '14:00-17:00', 'Thursday', 10),
(42, '14:00-17:00', 'Thursday', 11),
(43, '14:00-17:00', 'Friday', 11),
(44, '13:00-16:00', 'Saturday', 11),
(45, '13:00-16:00', 'Sunday', 11),
(46, '17:00-20:00', 'Sunday', 12),
(47, '17:00-20:00', 'Monday', 12),
(48, '16:00-18:00', 'Friday', 12),
(49, '16:00-18:00', 'Saturday', 12),
(50, '17:00-21:00', 'Wednesday', 13),
(51, '17:00-21:00', 'Thursday', 13),
(52, '10:00-14:00', 'Sunday', 13),
(53, '10:00-14:00', 'Monday', 13),
(54, '14:00-18:00', 'Tuesday', 14),
(55, '14:00-18:00', 'Wednesday', 14),
(56, '16:00-19:00', 'Tuesday', 14),
(57, '17:00-20:00', 'Thursday', 14),
(58, '11:00-14:00', 'Monday', 15),
(59, '11:00-14:00', 'Tuesday', 15),
(60, '14:00-17:00', 'Wednesday', 15),
(61, '13:00-16:00', 'Sunday', 15),
(62, '17:00-21:00', 'Wednesday', 17),
(63, '17:00-21:00', 'Thursday', 17),
(64, '10:00-14:00', 'Sunday', 17),
(65, '16:00-19:00', 'Wednesday', 17),
(66, '08:00-12:00', 'Friday', 19),
(67, '08:00-12:00', 'Saturday', 19),
(68, '17:00-20:00', 'Wednesday', 19),
(69, '17:00-20:00', 'Thursday', 19),
(70, '14:00-17:00', 'Thursday', 20),
(71, '14:00-17:00', 'Friday', 20),
(72, '13:00-16:00', 'Saturday', 20),
(73, '13:00-16:00', 'Sunday', 20);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `idDoctor` int(11) NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Department` varchar(45) NOT NULL,
  `Specialty` varchar(45) DEFAULT NULL,
  `Degree` varchar(250) NOT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`idDoctor`, `Name`, `Department`, `Specialty`, `Degree`, `User_idUser`) VALUES
(1, 'Prof. Dr. Md. Julhash Uddin', 'Medicine', 'Medicine Specialist', 'MBBS, FCPS, FCCP, FRCP (Glasgo)', 4),
(2, 'PROF. DR. MD. ABDUL MANNAN', 'Pediatric and Neonatology', 'Pediatric and Neonatology', 'MBBS,FCPS,MD(PAED),MD(NEONATOLOGY)', 5),
(3, 'DR ABU SALIM', 'Cardiology', 'Cardiology', 'MBBS,D,CARD,MD(CARDIOLOGY),FESC', 6),
(4, 'DR. ERFANUL HAQ SIDDIQUI', 'Orthopedic Surgeon', 'Orthopedic Specialist', 'MBBS(DMC), MS (Ortho),FRSH(London)', 7),
(5, 'Dr. Md. Ataullah Moon', 'Dental Surgeon', 'Dental Specialist', 'BDS, PGT', 8),
(6, 'Asst. Prof. Dr. Ali Asgar Chowdhury', 'Cancer Specialist', 'Cancer', 'MBBS, FCPS', 27),
(7, 'Prof. Dr. Md. Habibur Rahman', 'Dermatologist', 'Dermatology (Skin, Venereology)', 'MBBS, DDV ', 28),
(8, 'Capt Dr. H.S Ferdous', 'Diabetes, Thyroid and Hormone Specialist', 'Diabetes, Endocrine', 'MBBS, DEM (DU), FRMH, MACE, Ph.D Fellow', 29),
(9, 'Professor Dr. A.F. Mohiuddin Khan', 'ENT(Ear,Nose and Throat)', 'ENT', 'MBBS, DLO, MS', 30),
(10, 'Asst. Prof. Dr. A.K. Takib Uddin Ahmed', 'Pediatric and Neonatology', 'Neuromedicine Expert', 'MBBS, MD', 31),
(11, 'Professor Dr. Nausher Alam', 'Neurosurgery', 'Neurosurgeon', 'MBBS, FCPS, FICS', 32),
(12, 'Professor Dr. Syed Atiqul Haq', 'Family physician and medical co-ordinator', 'Physician Medicine', 'MBBS, FRCP, FCPS, MD', 33),
(13, 'Dr. Md. Abdur Rahim Miah', 'Gastroenterology', 'Gastroenterology Medicine', 'MBBS, MD', 34),
(14, 'Major  Dr. Laila Arjumand Banu', 'Gynecology and Obstetrics', 'Mother-child health care', 'MBBS, DGO , FCPS ', 35),
(15, 'Prof. Dr. Mahboob Ali', 'Interventional Cardiology', 'Heart, Cardiac Surgery, Cardiovascular, Hyper', 'MBBS, MD, FACC, FSCAI.', 36),
(17, 'Professor Dr. Momenuzzaman', 'Cardiology', 'Heart Dieases', 'MBBS, D-Card, MD-Card', 38),
(19, 'Prof. Dr. A.K.M. Anwar Ullah', 'Neuromedicine', 'MBBS, FCPS, FRCP', 'Neuron Specialised', 40),
(20, 'Prof. Dr. Md. Abdul Kalam', 'Plastic Surgery', 'Cosmetic & Plastic Surgery Specialist', 'MBBS, FCPS', 41);

-- --------------------------------------------------------

--
-- Table structure for table `pathologist`
--

CREATE TABLE `pathologist` (
  `idPathologist` int(11) NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Department` varchar(45) NOT NULL,
  `Speciality` varchar(45) NOT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pathologist`
--

INSERT INTO `pathologist` (`idPathologist`, `Name`, `Department`, `Speciality`, `User_idUser`) VALUES
(1, 'Siddikur Rahman', '1', 'Dental X-Ray', 9),
(3, 'Feroz Ali', '1', 'X-Ray ', 18),
(5, 'Joinal Hasan', '4', 'MRI', 22),
(6, 'Faisal Hamid', '3', 'ECG', 42),
(7, 'Qasem Ullah', '5', 'CT Scan', 43),
(8, 'Nur Uddin', '6', 'Full Blood Count Test', 44),
(9, 'Teyebul Khan', '8', 'Urine', 45),
(10, 'Toffazal Anwar', '9', 'Ultrasonography', 46),
(11, 'Junayed Hasan', '10', 'Echo-Cardiogram', 47),
(12, 'Enayet Mia', '11', 'Endoscopy', 48),
(13, 'Tarek Zaman', '12', 'ENT', 49),
(14, 'Md Malek', '13', 'Neurodiagnosis', 50);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `idPatient` int(11) NOT NULL,
  `Name` varchar(60) NOT NULL,
  `Sex` varchar(10) NOT NULL,
  `BloodGroup` varchar(5) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `MobileNo` varchar(15) DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `User_idUser` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`idPatient`, `Name`, `Sex`, `BloodGroup`, `DateOfBirth`, `MobileNo`, `Address`, `User_idUser`) VALUES
(1, 'Md. Fahim Shahrier Rasel', 'Male', 'A+', '1993-07-11', '01554070646', 'T-214, Middle Badda, Dhaka-1212', 1),
(3, 'Abdul Karim', 'Male', NULL, NULL, NULL, NULL, 11),
(4, 'Md Ahmed Hasan', 'Male', NULL, NULL, NULL, NULL, 12),
(5, 'Md Kamrul', 'Male', NULL, NULL, NULL, NULL, 15),
(6, 'Shamim Khan', 'Male', NULL, NULL, NULL, NULL, 17),
(7, 'Fatin Abrar', 'Male', NULL, NULL, NULL, NULL, 19),
(8, 'Saleh Ahmed', 'Male', NULL, NULL, NULL, NULL, 21),
(9, 'Muttakin Hossen', 'Male', 'B+', '1994-02-05', '01234567891', 'Motijheel', 26);

-- --------------------------------------------------------

--
-- Table structure for table `prescribedmedicine`
--

CREATE TABLE `prescribedmedicine` (
  `idPrescribedMedicine` int(11) NOT NULL,
  `Medicine` varchar(100) NOT NULL,
  `Dosage` varchar(45) NOT NULL,
  `Use` varchar(45) DEFAULT NULL,
  `Prescription_idPrescription` int(11) NOT NULL,
  `Prescription_Patient_idPatient` int(11) NOT NULL,
  `Prescription_Doctor_idDoctor` int(11) NOT NULL,
  `TestName` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prescribedmedicine`
--

INSERT INTO `prescribedmedicine` (`idPrescribedMedicine`, `Medicine`, `Dosage`, `Use`, `Prescription_idPrescription`, `Prescription_Patient_idPatient`, `Prescription_Doctor_idDoctor`, `TestName`) VALUES
(1, 'Napa', '1+1+1', '3 Days', 1, 1, 3, NULL),
(2, 'Amoxciline', '1+0+0', '3 Days', 1, 1, 3, NULL),
(3, 'SMC Orsaline', '1+0+1', '10 Days', 2, 1, 1, NULL),
(32, 'Lab Cal-D', '0+1+0', '5 Days', 35, 3, 1, 'City Scan'),
(33, 'Losectil', '1+1+1', '10 Days', 39, 6, 3, 'X-Ray'),
(34, 'NItroglycerin', '1+1+1', '15 Days', 41, 8, 3, 'MRI'),
(35, 'Inflame', '1+0+1', '7 Days', 42, 9, 1, 'X-Ray');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE `prescription` (
  `idPrescription` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Problem` varchar(300) DEFAULT NULL,
  `Patient_idPatient` int(11) NOT NULL,
  `Doctor_idDoctor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`idPrescription`, `Date`, `Problem`, `Patient_idPatient`, `Doctor_idDoctor`) VALUES
(1, '2017-08-04', 'High Fever', 1, 3),
(2, '2017-08-04', 'Low Pressure', 1, 1),
(35, '2018-03-22', 'Weakness', 3, 1),
(36, '2018-03-22', 'CCC', 3, 1),
(37, '2018-03-22', '', 3, 1),
(38, '2018-03-22', 'Weakness', 3, 1),
(39, '2018-03-23', 'Gastrology', 6, 3),
(40, '2018-03-23', '', 6, 3),
(41, '2018-03-26', 'Heart Pain', 8, 3),
(42, '2018-03-31', 'Pain in neck', 9, 1);

-- --------------------------------------------------------

--
-- Table structure for table `testaddingadmin`
--

CREATE TABLE `testaddingadmin` (
  `idTest` int(11) NOT NULL,
  `TestName` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `testaddingadmin`
--

INSERT INTO `testaddingadmin` (`idTest`, `TestName`) VALUES
(1, 'X-Ray'),
(3, 'ECG'),
(4, 'MRI'),
(5, 'CT Scan'),
(6, 'Full Blood Count Test'),
(8, 'Urine'),
(9, 'Ultrasonography'),
(10, 'Echo-Cardiogram'),
(11, 'Endoscopy'),
(12, 'ENT'),
(13, 'Neurodiagnosis ');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `idUser` int(11) NOT NULL,
  `UserName` varchar(45) NOT NULL,
  `Password` longtext NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Activation` tinyint(4) NOT NULL,
  `Image` longblob,
  `UserType` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`idUser`, `UserName`, `Password`, `Email`, `Activation`, `Image`, `UserType`) VALUES
(1, 'fahim', 'asdf1234', 'fahim@tb.com', 1, '', 'Patient'),
(4, 'julhasuddin', 'asdf1234', 'julhas@labaid.com', 1, NULL, 'Doctor'),
(5, 'abdulmannan', 'mannan1234', 'abdulmannan@labaid.com', 1, NULL, 'Doctor'),
(6, 'abusalim', 'salim1234', 'abusalim@labaid.com', 1, NULL, 'Doctor'),
(7, 'haqsiddiqui', 'siddiqui1234', 'haqsiddiqui@labaid.com', 1, NULL, 'Doctor'),
(8, 'ataullahmoon', 'moon1234', 'ataullahmoon@labaid.com', 1, NULL, 'Doctor'),
(9, 'siddikurrahman', 'asdfqwer', 'siddikrahman@tb.com', 1, '', 'Pathologist'),
(10, 'rasel', 'asdfqwer', 'rasel@tb.com', 1, NULL, 'Patient'),
(11, 'karim', 'asdf1234', 'karim@tb.com', 1, '', 'Patient'),
(12, 'mdahmedhasan', 'hasan1234', 'mdahmedhasan@gmail.com', 1, NULL, 'Patient'),
(13, 'shahjafor', 'shah1234', 'shahjafor@gmail.com', 1, NULL, 'Admin'),
(14, 'sakib77', 'sakib1234', 'sakib77@gmail.com', 1, NULL, 'Admin'),
(15, 'mdkamrul', 'kamrul12345', 'md@abc.com', 1, NULL, 'Patient'),
(16, 'mdmotalebmia', 'motaleb1234', 'mdmotalebmia@gmail.com', 1, NULL, 'Pathologist'),
(17, 'shamim', 'asdf1234', 'shamim@gmail.com', 1, NULL, 'Patient'),
(18, 'feroz', 'asdf1234', 'feroz@yahoo.com', 1, NULL, 'Pathologist'),
(19, 'fatin', 'asdf1234', 'fatim@hotmail.com', 1, NULL, 'Patient'),
(21, 'saleh', 'saleh1234', 'salehahmen@hotmail.com', 1, NULL, 'Patient'),
(22, 'joinal', 'joinal1234', 'joinalhasan@yahoo.com', 1, NULL, 'Pathologist'),
(26, 'muttakin', 'muttakin123', 'muttakin@hotmail.com', 1, NULL, 'Patient'),
(27, 'asgar1122', 'asgar1234', 'asgar@yahoo.com', 1, NULL, 'Doctor'),
(28, 'Habibur1122', 'habibur1234', 'habibur@yahoo.com', 1, NULL, 'Doctor'),
(29, 'ferdous', 'ferdous1234', 'ferdous@yahoo.com', 1, NULL, 'Doctor'),
(30, 'mohiuddin', 'mohiuddin1234', 'mohiuddin@gmail.com', 1, NULL, 'Doctor'),
(31, 'takib3344', 'takib1234', 'takib@yahoo.com', 1, NULL, 'Doctor'),
(32, 'nausher', 'nausher1234', 'nausher@hotmail.com', 1, NULL, 'Doctor'),
(33, 'atiqul', 'atiqul1234', 'atiqul@yahoo.com', 1, NULL, 'Doctor'),
(34, 'rahim1144', 'rahim1234', 'rahim1144@yahoo.com', 1, NULL, 'Doctor'),
(35, 'arjumand', 'arjumand1234', 'arjumand@hotmail.com', 1, NULL, 'Doctor'),
(36, 'mahboob3399', 'mahboob1234', 'mahboob@gmail.com', 1, NULL, 'Doctor'),
(38, 'momen8899', 'momen1234', 'momen@hotmail.com', 1, NULL, 'Doctor'),
(40, 'anwar7788', 'anwar1234', 'anwar@gmail.com', 1, NULL, 'Doctor'),
(41, 'kalam', 'kalam1234', 'kalam@hotmail.com', 1, NULL, 'Doctor'),
(42, 'faisal', 'faisal1234', 'faisal@yahoo.com', 1, NULL, 'Pathologist'),
(43, 'qasem', 'qasem1234', 'qasem@yahoo.com', 1, NULL, 'Pathologist'),
(44, 'nur', 'nur12345', 'nur@hotmail.com', 1, NULL, 'Pathologist'),
(45, 'tayebul', 'tayebul1234', 'tayebul@gmail.com', 1, NULL, 'Pathologist'),
(46, 'toffazal', 'toffazal1234', 'toffazal@yahoo.com', 1, NULL, 'Pathologist'),
(47, 'junayed', 'junayed1234', 'junayed@yahoo.com', 1, NULL, 'Pathologist'),
(48, 'enayet', 'enayet1234', 'enayet@hotmail.com', 1, NULL, 'Pathologist'),
(49, 'tarek', 'tarek1234', 'tarek@yahoo.com', 1, NULL, 'Pathologist'),
(50, 'malek', 'malek1234', 'malek@hotmail.com', 1, NULL, 'Pathologist');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`idAdmin`,`User_idUser`),
  ADD KEY `fk_Admin_User1_idx` (`User_idUser`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`idAppointment`,`Patient_idPatient`,`Doctor_idDoctor`),
  ADD KEY `fk_Appointment_Doctor1_idx` (`Doctor_idDoctor`),
  ADD KEY `fk_Appointment_Patient1_idx` (`Patient_idPatient`) USING BTREE;

--
-- Indexes for table `appointmenttesttimetable`
--
ALTER TABLE `appointmenttesttimetable`
  ADD PRIMARY KEY (`idAppointmentTestTimeTable`) USING BTREE,
  ADD KEY `patient_test_fk` (`patient_id`),
  ADD KEY `test_appoint_fk` (`idTest`);

--
-- Indexes for table `appointmenttimetable`
--
ALTER TABLE `appointmenttimetable`
  ADD PRIMARY KEY (`idAppointmentTimeTable`,`Doctor_idDoctor`),
  ADD KEY `fk_AppointmentTimeTable_Doctor1_idx` (`Doctor_idDoctor`) USING BTREE;

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`idDoctor`,`User_idUser`),
  ADD KEY `fk_Doctor_User1_idx` (`User_idUser`);

--
-- Indexes for table `pathologist`
--
ALTER TABLE `pathologist`
  ADD PRIMARY KEY (`idPathologist`,`User_idUser`),
  ADD KEY `fk_Pathologist_User1_idx` (`User_idUser`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`idPatient`,`User_idUser`),
  ADD KEY `fk_Patient_User1_idx` (`User_idUser`),
  ADD KEY `idPatient` (`idPatient`);

--
-- Indexes for table `prescribedmedicine`
--
ALTER TABLE `prescribedmedicine`
  ADD PRIMARY KEY (`idPrescribedMedicine`,`Prescription_idPrescription`,`Prescription_Patient_idPatient`,`Prescription_Doctor_idDoctor`),
  ADD KEY `fk_PrescribedMedicine_Prescription1_idx` (`Prescription_idPrescription`,`Prescription_Patient_idPatient`,`Prescription_Doctor_idDoctor`);

--
-- Indexes for table `prescription`
--
ALTER TABLE `prescription`
  ADD PRIMARY KEY (`idPrescription`,`Patient_idPatient`,`Doctor_idDoctor`),
  ADD KEY `fk_Prescription_Patient1_idx` (`Patient_idPatient`),
  ADD KEY `fk_Prescription_Doctor1_idx` (`Doctor_idDoctor`);

--
-- Indexes for table `testaddingadmin`
--
ALTER TABLE `testaddingadmin`
  ADD PRIMARY KEY (`idTest`,`TestName`) USING BTREE,
  ADD KEY `idTest` (`idTest`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`idUser`),
  ADD UNIQUE KEY `UserName_UNIQUE` (`UserName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `idAdmin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `idAppointment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `appointmenttesttimetable`
--
ALTER TABLE `appointmenttesttimetable`
  MODIFY `idAppointmentTestTimeTable` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `appointmenttimetable`
--
ALTER TABLE `appointmenttimetable`
  MODIFY `idAppointmentTimeTable` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `idDoctor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `pathologist`
--
ALTER TABLE `pathologist`
  MODIFY `idPathologist` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `idPatient` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `prescribedmedicine`
--
ALTER TABLE `prescribedmedicine`
  MODIFY `idPrescribedMedicine` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `prescription`
--
ALTER TABLE `prescription`
  MODIFY `idPrescription` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `testaddingadmin`
--
ALTER TABLE `testaddingadmin`
  MODIFY `idTest` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `fk_Admin_User1` FOREIGN KEY (`User_idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `fk_Appointment_Doctor1` FOREIGN KEY (`Doctor_idDoctor`) REFERENCES `doctor` (`idDoctor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Appointment_Patient1` FOREIGN KEY (`Patient_idPatient`) REFERENCES `patient` (`idPatient`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `appointmenttesttimetable`
--
ALTER TABLE `appointmenttesttimetable`
  ADD CONSTRAINT `patient_test_fk` FOREIGN KEY (`patient_id`) REFERENCES `patient` (`idPatient`),
  ADD CONSTRAINT `test_appoint_fk` FOREIGN KEY (`idTest`) REFERENCES `testaddingadmin` (`idTest`);

--
-- Constraints for table `appointmenttimetable`
--
ALTER TABLE `appointmenttimetable`
  ADD CONSTRAINT `fk_AppointmentTimeTable_Doctor1` FOREIGN KEY (`Doctor_idDoctor`) REFERENCES `doctor` (`idDoctor`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `doctor`
--
ALTER TABLE `doctor`
  ADD CONSTRAINT `fk_Doctor_User1` FOREIGN KEY (`User_idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `pathologist`
--
ALTER TABLE `pathologist`
  ADD CONSTRAINT `fk_Pathologist_User1` FOREIGN KEY (`User_idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `fk_Patient_User1` FOREIGN KEY (`User_idUser`) REFERENCES `user` (`idUser`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `prescribedmedicine`
--
ALTER TABLE `prescribedmedicine`
  ADD CONSTRAINT `fk_PrescribedMedicine_Prescription1` FOREIGN KEY (`Prescription_idPrescription`,`Prescription_Patient_idPatient`,`Prescription_Doctor_idDoctor`) REFERENCES `prescription` (`idPrescription`, `Patient_idPatient`, `Doctor_idDoctor`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `prescription`
--
ALTER TABLE `prescription`
  ADD CONSTRAINT `fk_Prescription_Doctor1` FOREIGN KEY (`Doctor_idDoctor`) REFERENCES `doctor` (`idDoctor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Prescription_Patient1` FOREIGN KEY (`Patient_idPatient`) REFERENCES `patient` (`idPatient`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
